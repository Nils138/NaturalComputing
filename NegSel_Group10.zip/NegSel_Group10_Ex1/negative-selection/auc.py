import matplotlib.pyplot as plt
import numpy as np

import argparse

parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('--anomalous_file', '-a', action='store', type=str, 
                    help='name of anomalous language')
parser.add_argument('--data_file', '-d', action='store', type=str,
                    help='name of data file')

args = parser.parse_args()

sensitivity, specificity = [], []
with open(args.anomalous_file) as t:
    total_anomalous = len(t.readlines())

with open(args.data_file) as file:
    total = file.readlines()
    anomalous = total[:total_anomalous]
    non_anomalous = total[total_anomalous:]

    lines = np.unique(np.array(sorted(total)))
    total_self = len(non_anomalous)

    sensitivity = np.array([(sum([1 for line2 in anomalous if float(line2)>float(unique)])/total_anomalous) for unique in lines])
    specificity=np.array([(sum([1 for line2 in non_anomalous if float(line2)<float(unique)])/total_self) for unique in lines])
specificity = 1-np.array(specificity)
sensitivity = np.array(sensitivity)
print("ROC-AUC", -1*np.trapz(sensitivity, specificity))
plt.plot(specificity, sensitivity) 
plt.plot([0,1])
plt.show()
